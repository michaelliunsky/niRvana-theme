<?php
/*
请将你的代码写在此处...

增加主题内容、脚本(Javascript)、样式(CSS)请使用WordPress钩子，不要修改代码。

使用方法范例：

想要在head引入样式/脚本，可以这么做：

function add_some_style_to_head() {
	echo '
	<style>
	body {background: #f00;}
	</style>
	';
}
add_action( 'wp_head', 'add_some_style_to_head' );

*/
?>
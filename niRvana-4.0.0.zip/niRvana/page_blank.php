<?php
/*
Template Name: 空白页面
*/
get_header();?><?php the_content(); ?><?php get_footer(); ?>